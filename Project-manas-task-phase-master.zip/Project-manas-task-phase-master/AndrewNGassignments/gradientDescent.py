def gradientDescent(X, Y, theta, alpha, iterations):
    m = Y.size
    X = np.hstack((np.ones((m,1)), X))
    for iters in range(iterations):
        H = np.dot(X, theta)
        theta -= alpha/m * np.dot(X.T, (H - Y))
    return theta
    
import os
import numpy as np

os.chdir('C:\\Users\\srinjoy\\Desktop\\ML\ex1')
data = np.genfromtxt('ex1data1.txt', delimiter = ',')
X = data[:,0:1]
Y = data[:,1:2]
theta = np.zeros((2,1))
theta = gradientDescent(X, Y, theta, 0.01, 1500)
print('Theta found by gradient descent: \n', theta)
     
