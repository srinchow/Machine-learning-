def gradientDescent(X, Y, theta, alpha, iterations):
    m = Y.size
    X = np.hstack((np.ones((m,1)), X))
    H = np.dot(X, theta)
    J = np.zeros((iterations, 1))
    for iters in range(iterations):
        H = np.dot(X, theta)
        J[iters] = 1/(2*m) * sum( ( H - Y )**2 )
        if ( iters > 0 and J[iters] > J[iters-1] ):
            break
        theta -= alpha/m * np.dot(X.T, (H - Y))
    return theta
    
import os
import numpy as np

os.chdir('C:\\Users\\srinjoy\\Desktop\\ML\ex1')
data = np.genfromtxt('ex1data2.txt', delimiter = ',')
m = data.shape[0]       #Number of training examples
n = data.shape[1] - 1   #Number of features
X = data[:,0:n]
Y = data[:,n:n+1]
theta = np.zeros((n+1,1))
theta = gradientDescent(X, Y, theta, 0.01, 400)
print('Theta found by gradient descent: \n', theta)
     
