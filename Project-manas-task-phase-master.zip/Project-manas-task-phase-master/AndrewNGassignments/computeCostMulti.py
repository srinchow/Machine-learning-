def computeCostMulti(X, Y, theta):
    m = Y.size
    X = np.hstack((np.ones((m,1)), X))
    H = np.dot(X, theta)
    cost = 1/(2*m) * sum( ( H - Y )**2 )
    return cost

import os
import numpy as np

os.chdir('C:\\Users\\Anubhav\\Desktop\\ML\ex1')
data = np.genfromtxt('ex1data2.txt', delimiter = ',')
m = data.shape[0]       #Number of training examples
n = data.shape[1] - 1   #Number of features
X = data[:,0:n]
Y = data[:,n:n+1]
theta = np.zeros((n+1, 1))
cost = computeCostMulti(X, Y, theta)
print('For theta : \n', theta, '\nComputed cost = ', cost)

