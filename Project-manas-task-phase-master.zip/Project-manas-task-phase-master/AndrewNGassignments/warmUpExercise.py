import numpy as np

def warmUpExcercise():
    print(np.eye(5))
    
print('5x5 Identity matrix')
warmUpExcercise()
