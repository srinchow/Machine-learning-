def computeCost(X, Y, theta):
    m = Y.size
    X = np.hstack((np.ones((m,1)), X))
    H = np.dot(X, theta)
    cost = 1/(2*m) * sum( ( H - Y )**2 )
    return cost

import os
import numpy as np

os.chdir('C:\\Users\\srinjoy\\Desktop\\ML\ex1')
data = np.genfromtxt('ex1data1.txt', delimiter = ',')
X = data[:,0:1]
Y = data[:,1:2]
theta = np.zeros((2,1))
cost = computeCost(X, Y, theta)
print('\nFor theta = ', theta, 'Cost computed = %f' % cost )
theta = np.array([ [-1], [2] ])
cost = computeCost(X, Y, theta)
print('\nFor theta = ', theta, 'Cost computed = %f' % cost )
