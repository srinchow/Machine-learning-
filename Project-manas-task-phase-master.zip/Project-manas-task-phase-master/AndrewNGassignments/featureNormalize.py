def featureNormalize(X):
    m = X.shape[0]
    mu = np.ones((m,2)) * np.mean(X, axis = 0)
    sigma = np.ones((m,2)) * np.std(X, axis = 0)
    X = (X - mu)/sigma
    return X
    
import os
import numpy as np

os.chdir('C:\\Users\\srinjoy\\Desktop\\ML\ex1')
data = np.genfromtxt('ex1data2.txt', delimiter = ',')
X = data[:,0:2]
Y = data[:,2:3]
m = Y.size
X = featureNormalize(X)
X = np.hstack((np.ones((m,1)), X))
print('Normalized X: \n', X)
