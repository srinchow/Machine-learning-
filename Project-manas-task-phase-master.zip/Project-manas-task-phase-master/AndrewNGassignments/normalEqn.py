def normalEqn(X, Y):
    m = Y.size
    n = X.shape[1] - 1
    X = np.hstack((np.ones((m,1)), X))
    theta = np.zeros((n, 1))
    inverse = np.linalg.inv(np.dot(X.T, X))
    theta = np.dot(np.dot(inverse, X.T), Y)
    return theta
    
import os
import numpy as np

os.chdir('C:\\Users\\srinjoy\\Desktop\\ML\ex1')
data = np.genfromtxt('ex1data1.txt', delimiter = ',')
m = data.shape[0]   #number of trainng examples
n = data.shape[1] - 1   #number of features
X = data[:,0:n]
Y = data[:,n:n+1]
theta = normalEqn(X, Y)
print('Theta found by normal equation: \n', theta)
     
